import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const calculateTimeLeft = (targetDate) => {
  const difference = +new Date(targetDate) - +new Date();
  let timeLeft = {};

  if (difference > 0) {
    timeLeft = {
      dias: Math.floor(difference / (1000 * 60 * 60 * 24)),
      horas: Math.floor((difference / (1000 * 60 * 60)) % 24),
      minutos: Math.floor((difference / 1000 / 60) % 60),
      segundos: Math.floor((difference / 1000) % 60),
    };
  }
  return timeLeft;
};

const Countdown = ({ targetDate }) => {
  const [timeLeft, setTimeLeft] = useState(calculateTimeLeft(targetDate));

  useEffect(() => {
    const timer = setTimeout(() => {
      setTimeLeft(calculateTimeLeft(targetDate));
    }, 1000);

    return () => clearTimeout(timer);
  });

  const timerComponents = [];

  Object.keys(timeLeft).forEach((interval) => {
    if (!timeLeft[interval]) {
      return;
    }

    timerComponents.push(
      <motion.span
        key={interval}
        className="flex flex-col items-center mx-2 p-3 bg-white/20 backdrop-blur-sm rounded-xl shadow-lg"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <span className="text-4xl md:text-5xl font-bold text-white drop-shadow-lg">
          {timeLeft[interval]}
        </span>
        <span className="text-sm md:text-base text-white font-medium uppercase mt-1">
          {interval}
        </span>
      </motion.span>
    );
  });

  return (
    <div className="text-center my-8">
      <motion.p
        className="text-white text-2xl md:text-3xl font-semibold mb-4 drop-shadow-lg"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        Faltan:
      </motion.p>
      <div className="flex justify-center">
        {timerComponents.length ? (
          timerComponents
        ) : (
          <motion.span
            className="text-white text-3xl font-bold"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            ¡Es el gran día!
          </motion.span>
        )}
      </div>
    </div>
  );
};

export default Countdown;