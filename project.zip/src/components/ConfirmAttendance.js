import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FaWhatsapp } from 'react-icons/fa';

const ConfirmAttendance = ({ phoneNumber }) => {
  const [name, setName] = useState('');
  const [willAttend, setWillAttend] = useState('');
  const [guests, setGuests] = useState(1);
  const [message, setMessage] = useState('');
  const [confirmationSent, setConfirmationSent] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    let whatsappMessage = `¡Hola Juan y Citlali!\n\nMi nombre es: ${name}\n`;
    whatsappMessage += `Asistiré: ${willAttend === 'yes' ? 'Sí' : 'No'}\n`;
    if (willAttend === 'yes') {
      whatsappMessage += `Número de invitados: ${guests}\n`;
    }
    if (message) {
      whatsappMessage += `Mensaje para los novios: ${message}\n`;
    }

    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(whatsappMessage)}`;
    window.open(whatsappUrl, '_blank');
    setConfirmationSent(true); // Marcar que la confirmación ha sido enviada
  };

  return (
    <motion.div
      className="bg-white/80 backdrop-blur-xl border border-gray-200/50 rounded-3xl p-8 shadow-xl max-w-md mx-auto my-8"
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.2 }}
    >
      <h2 className="text-3xl font-bold text-center text-gray-800 mb-6 font-serif">
        Confirma tu Asistencia
      </h2>
      {confirmationSent ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center text-green-700 font-semibold text-xl"
        >
          <p>¡Gracias por confirmar tu asistencia!</p>
          <p>Hemos enviado tu mensaje a Juan y Citlali.</p>
          <p className="mt-4">¡Nos vemos en la boda!</p>
        </motion.div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label htmlFor="name" className="block text-gray-700 text-lg font-medium mb-2">
              Tu Nombre:
            </label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-400 text-gray-800"
              placeholder="Ej. Tu Nombre Completo"
              required
            />
          </div>

          <div>
            <label htmlFor="willAttend" className="block text-gray-700 text-lg font-medium mb-2">
              ¿Asistirás?
            </label>
            <select
              id="willAttend"
              value={willAttend}
              onChange={(e) => setWillAttend(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-400 text-gray-800"
              required
            >
              <option value="">Selecciona una opción</option>
              <option value="yes">Sí, asistiré</option>
              <option value="no">No podré asistir</option>
            </select>
          </div>

          {willAttend === 'yes' && (
            <div>
              <label htmlFor="guests" className="block text-gray-700 text-lg font-medium mb-2">
                Número de Invitados (incluyéndote):
              </label>
              <select
                id="guests"
                value={guests}
                onChange={(e) => setGuests(parseInt(e.target.value))}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-400 text-gray-800"
              >
                {[...Array(10).keys()].map((i) => (
                  <option key={i + 1} value={i + 1}>
                    {i + 1}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label htmlFor="message" className="block text-gray-700 text-lg font-medium mb-2">
              Mensaje para los Novios (opcional):
            </label>
            <textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows="4"
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-400 text-gray-800"
              placeholder="¡Felicidades! Les deseo lo mejor..."
            ></textarea>
          </div>

          <motion.button
            type="submit"
            className="w-full flex items-center justify-center px-6 py-3 bg-gradient-to-r from-green-500 to-teal-600 text-white font-semibold rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <FaWhatsapp className="mr-2 text-xl" />
            Enviar Confirmación por WhatsApp
          </motion.button>
        </form>
      )}
    </motion.div>
  );
};

export default ConfirmAttendance;