import React from 'react';
import { motion } from 'framer-motion';

const Heart = () => {
  const duration = Math.random() * 3 + 2; // Duración entre 2 y 5 segundos
  const delay = Math.random() * 2; // Retraso entre 0 y 2 segundos
  const size = Math.random() * 20 + 10; // Tamaño entre 10 y 30px
  const startX = Math.random() * 100; // Posición inicial X entre 0 y 100%
  const endX = startX + (Math.random() - 0.5) * 50; // Posición final X, un poco aleatoria
  const opacity = Math.random() * 0.5 + 0.5; // Opacidad entre 0.5 y 1

  return (
    <motion.div
      className="absolute text-red-400"
      style={{
        left: `${startX}vw`,
        fontSize: `${size}px`,
        opacity: opacity,
        pointerEvents: 'none',
        // Aseguramos que los corazones estén por encima de todo
        zIndex: 9999, 
      }}
      initial={{ y: '100vh', x: 0, opacity: 0 }}
      animate={{
        y: '-10vh',
        x: `${endX - startX}vw`,
        opacity: [opacity, opacity, 0],
      }}
      transition={{
        duration: duration,
        ease: 'linear',
        repeat: Infinity,
        delay: delay,
      }}
    >
      ❤️
    </motion.div>
  );
};

export default Heart;