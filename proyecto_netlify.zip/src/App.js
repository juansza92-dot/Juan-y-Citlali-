import React, { useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Countdown from './components/Countdown';
import LocationButton from './components/LocationButton';
import ConfirmAttendance from './components/ConfirmAttendance';
import Heart from './components/Heart';

const App = () => {
  const weddingDate = '2025-10-11T13:00:00'; // Sábado 11 de octubre del 2025, 1 PM
  const whatsappNumber = '524921876213'; // Número de WhatsApp para confirmar asistencia
  const songUrl = 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'; // URL de tu canción (¡cambia esto por tu canción!)

  const parentsBride = [
    "Francisco Javier Guapo Reyes", // Papá de la novia primero
    "Esperanza Reyes Moreno" // Mamá de la novia después
  ];

  const parentsGroom = [
    "Juan Bautista Sanchez Zambrano",
    "Josefina Zambrano Juárez"
  ];

  const images = [
    { src: "https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc00BqYZRLoPyS6Nz5GRraqmfKLZjOQCH78nhAg", title: "Primera Cita" },
    { src: "https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc04vAtp9007fmwyReAgKCraUIWzEDZ6on58JNO", title: "Nuestra Boda Civil" },
    { src: "https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc0FOXNVADzTWwmhl5UyNfsFj9RSnotvEAKeiMb", title: "Momentos especiales" },
    { src: "https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc0hH6PyLzuUK73FIu6QMZBiVNxCwz4OT8kREWf", title: "Más momentos especiales" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-100 to-red-100 relative overflow-hidden font-serif text-gray-800">
      {/* Corazones flotantes - Aseguramos que estén por encima de todo con z-index */}
      <div className="fixed inset-0 pointer-events-none z-50">
        {[...Array(50).keys()].map((i) => (
          <Heart key={i} />
        ))}
      </div>

      {/* Audio para la canción de fondo */}
      <audio src={songUrl} autoPlay loop controls className="hidden">
        Tu navegador no soporta el elemento de audio.
      </audio>

      {/* Primera sección con fondo de imagen y opacidad */}
      <div
        className="relative min-h-screen flex flex-col items-center justify-center text-center p-6"
        style={{
          backgroundImage: `url(https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc04vAtp9007fmwyReAgKCraUIWzEDZ6on58JNO)`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed', /* Para que la imagen de fondo se fije y no se desplace */
        }}
      >
        <div className="absolute inset-0 bg-black opacity-40 z-10"></div> {/* Opacidad del 80% sobre la imagen */}
        <motion.div
          className="relative z-20 text-white py-8 px-4 md:py-0 flex flex-col justify-center items-center min-h-screen w-full max-w-4xl mx-auto" /* Ajuste de padding y ancho máximo */
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          {/* Título "Nuestra Boda" arriba de Juan & Citlali */}
          <motion.h1
            className="text-5xl md:text-6xl font-bold mb-4 drop-shadow-lg font-cursive leading-tight"
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
          >
            Nuestra Boda
          </motion.h1>

          <h1 className="text-5xl md:text-7xl font-bold mb-4 drop-shadow-lg font-cursive leading-tight"> {/* Ajuste de tamaño de fuente y line-height */}
            Juan & Citlali
          </h1>
          <p className="text-lg md:text-2xl mb-8 font-light italic drop-shadow-lg"> {/* Ajuste de tamaño de fuente */}
            Tenemos el placer de invitarte a celebrar con nosotros este día tan especial
          </p>
          <p className="text-3xl md:text-4xl font-semibold mb-8 drop-shadow-lg"> {/* Ajuste de tamaño de fuente */}
            Sábado 11 de octubre del 2025
          </p>
          <Countdown targetDate={weddingDate} />
        </motion.div>
      </div>

      {/* Contenido restante de la invitación */}
      <div className="relative z-10 bg-gradient-to-br from-purple-100 via-pink-100 to-red-100"> {/* Fondo para el resto de secciones */}
        {/* Sección de fotos y frase */}
        <div className="container mx-auto px-4 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            {images.map((image, index) => (
              <motion.div
                key={index}
                className="bg-white/70 backdrop-blur-sm rounded-3xl shadow-xl overflow-hidden p-4"
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <h3 className="text-2xl font-bold text-center text-gray-800 mb-4 font-cursive">{image.title}</h3>
                <img src={image.src} alt={image.title} className="w-full h-auto object-cover rounded-2xl" />
              </motion.div>
            ))}
          </div>
          <motion.p
            className="text-center text-3xl md:text-4xl italic font-semibold text-gray-700 my-12 px-4"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.8 }}
          >
            "El amor no es mirarse el uno al otro, es mirar juntos en la misma dirección."
          </motion.p>
        </div>

        {/* Sección de papás */}
        <div className="bg-white/70 backdrop-blur-xl rounded-3xl shadow-xl p-8 mx-auto max-w-3xl my-12">
          <motion.h2
            className="text-3xl md:text-4xl font-bold text-center text-gray-800 mb-8 font-cursive"
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.6 }}
          >
            En compañía de nuestros papás
          </motion.h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ duration: 0.7 }}
            >
              <h3 className="text-2xl font-semibold text-purple-700 mb-3 font-cursive">Papás de la Novia</h3>
              {parentsBride.map((parent, index) => (
                <p key={index} className="text-xl text-gray-700 italic mb-2">
                  {parent}
                </p>
              ))}
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ duration: 0.7 }}
            >
              <h3 className="text-2xl font-semibold text-pink-700 mb-3 font-cursive">Papás del Novio</h3>
              {parentsGroom.map((parent, index) => (
                <p key={index} className="text-xl text-gray-700 italic mb-2">
                  {parent}
                </p>
              ))}
            </motion.div>
          </div>
        </div>

        {/* Sección de Ubicaciones */}
        <div className="container mx-auto px-4 py-16">
          <motion.h2
            className="text-4xl font-bold text-center text-gray-800 mb-10 font-cursive"
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.6 }}
          >
            ¿Dónde y Cuándo?
          </motion.h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <motion.div
              className="bg-white/80 backdrop-blur-xl border border-gray-200/50 rounded-3xl p-8 shadow-xl text-center"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ duration: 0.7 }}
            >
              <h3 className="text-3xl font-bold text-purple-700 mb-4 font-cursive">Misa</h3>
              <p className="text-xl text-gray-700 mb-4">
                Capilla de Nápoles
                <br />
                1:00 PM
              </p>
              <LocationButton label="Ver en Mapa" link="https://maps.app.goo.gl/6y9FfLqUPKqLEpKi7" />
            </motion.div>

            <motion.div
              className="bg-white/80 backdrop-blur-xl border border-gray-200/50 rounded-3xl p-8 shadow-xl text-center"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ duration: 0.7 }}
            >
              <h3 className="text-3xl font-bold text-pink-700 mb-4 font-cursive">Recepción</h3>
              <p className="text-xl text-gray-700 mb-4">
                Salón Elegans
                <br />
                A partir de las 3:00 PM
              </p>
              <LocationButton label="Ver en Mapa" link="https://maps.app.goo.gl/kvemU8s6ceV1TTcBA" />
            </motion.div>
          </div>
        </div>

        {/* Sección de Confirmar Asistencia */}
        <ConfirmAttendance phoneNumber={whatsappNumber} />

        <motion.div
          className="text-center text-2xl md:text-3xl font-semibold text-gray-700 my-12 px-4"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.8 }}
        >
          <p>¡Esperamos contar con tu presencia para celebrar este día tan especial!</p>
          <p className="mt-4">Con cariño,</p>
          <p className="text-3xl md:text-4xl font-cursive text-purple-700">Juan y Citlali</p>
        </motion.div>

        <footer className="text-center py-8 text-gray-600 text-sm">
          <p>&copy; 2025 Juan & Citlali. Todos los derechos reservados.</p>
        </footer>
      </div>
    </div>
  );
};

export default App;